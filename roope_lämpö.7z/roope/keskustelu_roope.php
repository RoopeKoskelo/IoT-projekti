<!DOCTYPE html>
<?php
include("scripts/chatconfig.php");
include("scripts/chat_data.php");
?>
<head>
	<title>Keskustelupalsta</title>
</head>
<body>
	<h1>Keskustelupalsta</h1>
	<div>
		<form action="handle.php" method="post">
			Nimi: <input type="text" name="nimi"><br>
			Viesti: <textarea name="viesti"></textarea><br>
			<input type="submit">
		</form>
		<a href="lampo_ROOPE.php"> <--Etusivulle </a>
	</div>
	<div>
		<p>
			<?php
				echo $message;
			?>
		</p>
	</div>
</body>
