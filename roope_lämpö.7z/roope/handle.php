<?php
include("scripts/chatconfig.php");

$conn = new mysqli($databaseHost, $databaseUsername, $databasePassword, $databaseName);

if ($conn->connect_error) {
	die("Connection failed: ". $conn->connect_error);
	}

$nimi = $_POST["nimi"];
$viesti = $_POST["viesti"];
$stmt = $conn->prepare("INSERT INTO chat (nimi, viesti) VALUES (?, ?)");
$stmt->bind_param("ss", $nimi, $viesti);

$stmt->execute();

$conn->close();

header("Location: keskustelu_roope.php");
die();
?>
