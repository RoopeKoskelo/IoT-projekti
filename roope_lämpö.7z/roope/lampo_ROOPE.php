<!DOCTYPE html>          
<?php
  include("config.php");
  include("scripts/data.php");
?>
<html>
  <head>    
    <title>
      Lämpö ja Kosteus
    </title>
    <link rel="stylesheet" href="style/style.css">
    <script type="text/javascript">
      var lampo = <?php echo $chartTemp;?>;
      var kosteus = <?php echo $chartHumid;?>;
    </script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript" src="scripts/chart.js"></script>
  </head>
    <body>
      <div style="border:2px double black; text-align:center;">
        <h1>Lämpö- ja kosteusanturi:</h1>
        <p>Powered by 100% pure memes</p>
      </div>
      <br>
      <div style="text-align:center">
        <img src="images/kekw" width=200px>
          <div>
            <div id="chart_div" style="width: 400px; height: 120px;"></div>
            <table>          
              <tr>
                <th>pvm/aika</th>
                <th>lämpö</th>
                <th>kosteus</th>
              </tr>          
              <?php
                echo $tabledata;
              ?>
            </table>
            <a href="keskustelu_roope.php">Keskustelupalsta</a>
          </div>
      </div>
    </body>
</html>
