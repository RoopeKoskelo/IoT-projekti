<?php
	$databaseHost = "localhost";
	$databaseUsername = "root";
	$databasePassword = "kissa123";
	$databaseName = "ROOPE_DHT11";
?>
