<?php
include("chatconfig.php");

	$conn = new mysqli($databaseHost, $databaseUsername, $databasePassword, $databaseName);

	if ($conn->connect_error) {
		die("Connection failed: ". $conn->connect_error);
		}
	$sql = "SELECT * FROM chat";
	$result = $conn->query($sql);

	while($row = $result->fetch_assoc())
			{
				$message.=
				$row[nimi]. "<br>".
				$row[viesti]."<br><br>";
			}
	$conn->close();
?>

