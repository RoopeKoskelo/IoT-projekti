<?php
	include("config.php");
	
      $conn = new mysqli($databaseHost, $databaseUsername, $databasePassword, $databaseName);
      if($conn->connect_error){
          die("Connection failed: " . $conn->connect_error);
      }
      $sql = "SELECT id, aika, lampo, kosteus FROM DHT11 ORDER BY id DESC LIMIT 10";
      $output = $conn->query($sql);
      $conn->close();
      
      $tabledata = "";
      
      $chartTemp = "";
      $chartHumid = "";
      
      while($row = $output->fetch_assoc())
              {
                $tabledata.=
                  "<tr>".
                    "<td>". $row[aika]."</td>".
                    "<td>". $row[lampo]."</td>".
                    "<td>". $row[kosteus]."</td>".
                  "</tr>";
                if (strlen($chartTemp) > 0){
                }
                  else{
                $chartTemp = $row[lampo];
                $chartHumid = $row[kosteus];
                }
              }
?>
